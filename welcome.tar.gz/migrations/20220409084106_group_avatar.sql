alter table "group" add column avatar_updated_at timestamp not null default '1970-01-01 00:00:00';
