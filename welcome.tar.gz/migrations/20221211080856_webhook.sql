alter table
    "user"
add
    column webhook_url text;