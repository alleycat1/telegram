alter table "user" add column status char not null default 0;
