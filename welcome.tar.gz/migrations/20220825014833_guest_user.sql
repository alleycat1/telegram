alter table "user" add column is_guest boolean not null default false;
